using System.Drawing;
using System.Windows.Forms;

namespace ExercicioWinForms;

partial class FrmPedidos
{
    private void InitializeComponent()
    {
        ClientSize = new Size(400, 200);
        StartPosition = FormStartPosition.CenterParent;
        Text = "Pedidos";
        var titulo = new Label();
        titulo.AutoSize = true;
        titulo.Location = new Point(24, 26);
        titulo.Text = "Pedidos";
        Controls.Add(titulo);
    }
}
