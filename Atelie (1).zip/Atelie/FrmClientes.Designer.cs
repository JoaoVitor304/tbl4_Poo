using System.Drawing;
using System.Windows.Forms;

namespace ExercicioWinForms;

partial class FrmClientes
{
    private void InitializeComponent()
    {
        ClientSize = new Size(400, 200);
        StartPosition = FormStartPosition.CenterParent;
        Text = "Clientes";
        var titulo = new Label();
        titulo.AutoSize = true;
        titulo.Location = new Point(24, 26);
        titulo.Text = "Clientes";
        Controls.Add(titulo);
    }
}
