using System.Windows.Forms;

namespace ExercicioWinForms;

public partial class FrmProdutos : Form
{
    public FrmProdutos()
    {
        InitializeComponent();
        Atelie.Secao(this, 1);
    }
}
