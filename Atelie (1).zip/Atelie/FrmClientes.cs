using System.Windows.Forms;

namespace ExercicioWinForms;

public partial class FrmClientes : Form
{
    public FrmClientes()
    {
        InitializeComponent();
        Atelie.Secao(this, 0);
    }
}
