using System.Drawing;
using System.Windows.Forms;

namespace ExercicioWinForms;

partial class FrmPrincipal
{
    private Button btnMaximizar;
    private Button btnRestaurar;
    private Button btnFechar;
    private Button btnClientes;
    private Button btnProdutos;
    private Button btnPedidos;

    private void InitializeComponent()
    {
        SuspendLayout();
        ClientSize = new Size(640, 300);
        MinimumSize = new Size(520, 240);
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Menu principal";

        btnMaximizar = new Button();
        btnMaximizar.Name = "btnMaximizar";
        btnMaximizar.Text = "Maximizar";
        btnMaximizar.Location = new Point(400, 16);
        btnMaximizar.Size = new Size(110, 38);
        btnMaximizar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnMaximizar.Click += btnMaximizar_Click;
        Controls.Add(btnMaximizar);

        btnRestaurar = new Button();
        btnRestaurar.Name = "btnRestaurar";
        btnRestaurar.Text = "Restaurar";
        btnRestaurar.Location = new Point(400, 16);
        btnRestaurar.Size = new Size(110, 38);
        btnRestaurar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnRestaurar.Click += btnRestaurar_Click;
        Controls.Add(btnRestaurar);

        btnFechar = new Button();
        btnFechar.Name = "btnFechar";
        btnFechar.Text = "Fechar";
        btnFechar.Location = new Point(518, 16);
        btnFechar.Size = new Size(110, 38);
        btnFechar.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnFechar.Click += btnFechar_Click;
        Controls.Add(btnFechar);

        btnClientes = new Button();
        btnClientes.Name = "btnClientes";
        btnClientes.Text = "Clientes";
        btnClientes.Location = new Point(30, 110);
        btnClientes.Size = new Size(136, 38);
        btnClientes.Anchor = AnchorStyles.Top | AnchorStyles.Left;
        btnClientes.Click += btnClientes_Click;
        Controls.Add(btnClientes);

        btnProdutos = new Button();
        btnProdutos.Name = "btnProdutos";
        btnProdutos.Text = "Produtos";
        btnProdutos.Location = new Point(180, 110);
        btnProdutos.Size = new Size(136, 38);
        btnProdutos.Anchor = AnchorStyles.Top | AnchorStyles.Left;
        btnProdutos.Click += btnProdutos_Click;
        Controls.Add(btnProdutos);

        btnPedidos = new Button();
        btnPedidos.Name = "btnPedidos";
        btnPedidos.Text = "Pedidos";
        btnPedidos.Location = new Point(330, 110);
        btnPedidos.Size = new Size(136, 38);
        btnPedidos.Anchor = AnchorStyles.Top | AnchorStyles.Left;
        btnPedidos.Click += btnPedidos_Click;
        Controls.Add(btnPedidos);
        btnRestaurar.Visible = false;
        Resize += FrmPrincipal_Resize;
        ResumeLayout(false);
    }
}
