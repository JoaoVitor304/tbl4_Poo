using System.Windows.Forms;

namespace ExercicioWinForms;

public partial class FrmPedidos : Form
{
    public FrmPedidos()
    {
        InitializeComponent();
        Atelie.Secao(this, 2);
    }
}
