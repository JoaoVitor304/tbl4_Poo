using System;
using System.Windows.Forms;

namespace ExercicioWinForms;

public partial class FrmPrincipal : Form
{
    public FrmPrincipal()
    {
        InitializeComponent();
        Atelie.Menu(this, new[] { btnClientes, btnProdutos, btnPedidos }, btnMaximizar, btnRestaurar, btnFechar);
    }

    private void btnMaximizar_Click(object sender, EventArgs e)
    {
        WindowState = FormWindowState.Maximized;
    }

    private void btnRestaurar_Click(object sender, EventArgs e)
    {
        WindowState = FormWindowState.Normal;
    }

    private void FrmPrincipal_Resize(object sender, EventArgs e)
    {
        btnRestaurar.Visible = WindowState == FormWindowState.Maximized;
        btnMaximizar.Visible = WindowState != FormWindowState.Maximized;
    }

    private void btnFechar_Click(object sender, EventArgs e)
    {
        Close();
    }

    private void btnClientes_Click(object sender, EventArgs e)
    {
        using var tela = new FrmClientes();
        tela.ShowDialog(this);
    }

    private void btnProdutos_Click(object sender, EventArgs e)
    {
        using var tela = new FrmProdutos();
        tela.ShowDialog(this);
    }

    private void btnPedidos_Click(object sender, EventArgs e)
    {
        using var tela = new FrmPedidos();
        tela.ShowDialog(this);
    }
}
