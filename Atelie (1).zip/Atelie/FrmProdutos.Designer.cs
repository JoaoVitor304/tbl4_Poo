using System.Drawing;
using System.Windows.Forms;

namespace ExercicioWinForms;

partial class FrmProdutos
{
    private void InitializeComponent()
    {
        ClientSize = new Size(400, 200);
        StartPosition = FormStartPosition.CenterParent;
        Text = "Produtos";
        var titulo = new Label();
        titulo.AutoSize = true;
        titulo.Location = new Point(24, 26);
        titulo.Text = "Produtos";
        Controls.Add(titulo);
    }
}
