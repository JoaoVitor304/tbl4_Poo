using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ExercicioWinForms;

internal static class Atelie
{
    private static readonly Color Papel = Color.FromArgb(248, 245, 237);
    private static readonly Color Tinta = Color.FromArgb(38, 53, 48);
    private static readonly Color Argila = Color.FromArgb(148, 65, 41);
    private static readonly Color Areia = Color.FromArgb(229, 222, 206);
    private static readonly string[] Modulos = { "Clientes", "Produtos", "Pedidos" };
    private static readonly string[][] Colunas = {
        new[] { "Cliente", "Cidade" },
        new[] { "Produto", "Categoria", "Preço" },
        new[] { "Pedido", "Cliente", "Produto", "Situação" }
    };
    private static readonly string[][][] Linhas = {
        new[] { new[] { "Casa Aurora", "Uberlândia" }, new[] { "Estúdio Ipê", "Araguari" }, new[] { "Loja Amora", "Uberaba" } },
        new[] { new[] { "Vaso Alba", "Cerâmica", "R$ 89,00" }, new[] { "Bandeja Flora", "Madeira", "R$ 120,00" }, new[] { "Manta Terra", "Têxtil", "R$ 165,00" } },
        new[] { new[] { "#1003", "Casa Aurora", "Vaso Alba", "Em preparo" }, new[] { "#1002", "Estúdio Ipê", "Bandeja Flora", "Enviado" }, new[] { "#1001", "Loja Amora", "Manta Terra", "Entregue" } }
    };

    private static Label Texto(string valor, float tamanho, Color cor, bool titulo = false)
    {
        return new Label {
            Text = valor, Dock = DockStyle.Fill, ForeColor = cor,
            Font = new Font(titulo ? "Georgia" : "Segoe UI", tamanho),
            TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true
        };
    }

    private static TableLayoutPanel LinhasFixas(params int[] alturas)
    {
        var painel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = alturas.Length, Margin = Padding.Empty };
        painel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        foreach (int altura in alturas)
            painel.RowStyles.Add(altura == 0 ? new RowStyle(SizeType.Percent, 100) : new RowStyle(SizeType.Absolute, altura));
        return painel;
    }

    private static void Estilo(Button botao, Color fundo, Color frente)
    {
        botao.FlatStyle = FlatStyle.Flat;
        botao.FlatAppearance.BorderSize = 0;
        botao.BackColor = fundo;
        botao.ForeColor = frente;
        botao.Font = new Font("Segoe UI", 10);
        botao.Cursor = Cursors.Hand;
        botao.UseVisualStyleBackColor = false;
    }

    private static void Base(Form form)
    {
        form.SuspendLayout();
        form.BackColor = Papel;
        form.Font = new Font("Segoe UI", 10);
        form.MinimumSize = new Size(740, 530);
        form.ClientSize = new Size(910, 570);
    }

    private static Control Tabela(int modulo, string busca = "")
    {
        var lista = new ListView {
            Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, MultiSelect = false,
            HeaderStyle = ColumnHeaderStyle.Nonclickable, BorderStyle = BorderStyle.None,
            BackColor = Color.White, ForeColor = Tinta, Font = new Font("Segoe UI", 11),
            AccessibleName = Modulos[modulo], Margin = Padding.Empty
        };
        foreach (string coluna in Colunas[modulo]) lista.Columns.Add(coluna);
        foreach (var linha in Linhas[modulo].Where(l => l.Any(c => c.Contains(busca, StringComparison.CurrentCultureIgnoreCase))))
        {
            var item = new ListViewItem(linha);
            item.BackColor = lista.Items.Count % 2 == 0 ? Color.White : Papel;
            lista.Items.Add(item);
        }
        if (lista.Items.Count == 0)
            lista.Items.Add(new ListViewItem("Nenhum resultado"));
        void Ajustar() {
            int largura = Math.Max(1, (lista.ClientSize.Width - 8) / lista.Columns.Count);
            foreach (ColumnHeader coluna in lista.Columns) coluna.Width = largura;
        }
        lista.SizeChanged += (_, _) => Ajustar();
        return lista;
    }

    public static void Menu(Form form, Button[] atalhos, Button maximizar, Button restaurar, Button fechar)
    {
        Base(form);
        form.Text = "Ateliê • Visão geral";
        var pagina = LinhasFixas(64, 0);
        form.Controls.Add(pagina);
        var topo = new Panel { Dock = DockStyle.Fill, BackColor = Tinta, Padding = new Padding(26, 0, 12, 0), Margin = Padding.Empty };
        topo.Controls.Add(Texto("Ateliê   /   Gestão", 19, Papel, true));
        var acoes = new FlowLayoutPanel { Dock = DockStyle.Right, Width = 260, Padding = new Padding(0, 12, 0, 0), WrapContents = false };
        foreach (var b in new[] { maximizar, restaurar, fechar }) {
            Estilo(b, Tinta, Papel);
            b.Size = new Size(112, 34);
            b.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            acoes.Controls.Add(b);
        }
        topo.Controls.Add(acoes);
        acoes.BringToFront();
        pagina.Controls.Add(topo, 0, 0);
        var corpo = LinhasFixas(56, 84, 54, 0, 30);
        corpo.Padding = new Padding(30, 16, 30, 12);
        pagina.Controls.Add(corpo, 0, 1);
        corpo.Controls.Add(Texto("Visão geral", 28, Tinta, true), 0, 0);
        var nav = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1, Margin = Padding.Empty };
        Color[] tons = { Argila, Tinta, Areia };
        for (int i = 0; i < atalhos.Length; i++) {
            nav.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / 3));
            var b = atalhos[i];
            Estilo(b, tons[i], i == 2 ? Tinta : Papel);
            b.Font = new Font("Georgia", 18);
            b.Text = Modulos[i] + "  ›";
            b.Dock = DockStyle.Fill;
            b.Margin = new Padding(0, 5, i == 2 ? 0 : 10, 5);
            nav.Controls.Add(b, i, 0);
        }
        corpo.Controls.Add(nav, 0, 1);
        corpo.Controls.Add(Texto("Últimos pedidos", 19, Tinta, true), 0, 2);
        corpo.Controls.Add(Tabela(2), 0, 3);
        corpo.Controls.Add(Texto("Dados demonstrativos", 9, Argila), 0, 4);
        form.ResumeLayout(true);
    }

    public static void Secao(Form form, int modulo)
    {
        Base(form);
        foreach (Control c in form.Controls.Cast<Control>().ToArray()) c.Dispose();
        form.Text = Modulos[modulo] + " • Ateliê";
        var corpo = LinhasFixas(40, 64, 50, 0, 32);
        corpo.Padding = new Padding(28, 16, 28, 12);
        form.Controls.Add(corpo);
        var voltar = new Button { Text = "‹  Voltar ao menu", AutoSize = true, Dock = DockStyle.Left, DialogResult = DialogResult.Cancel };
        Estilo(voltar, Tinta, Papel);
        form.CancelButton = voltar;
        corpo.Controls.Add(voltar, 0, 0);
        corpo.Controls.Add(Texto(Modulos[modulo], 30, Tinta, true), 0, 1);
        var busca = new TextBox { Dock = DockStyle.Top, PlaceholderText = "Buscar em " + Modulos[modulo].ToLower() + "…", AccessibleName = "Busca", Font = new Font("Segoe UI", 12) };
        corpo.Controls.Add(busca, 0, 2);
        Control tabela = Tabela(modulo);
        corpo.Controls.Add(tabela, 0, 3);
        busca.TextChanged += (_, _) => {
            tabela.Dispose();
            tabela = Tabela(modulo, busca.Text.Trim());
            corpo.Controls.Add(tabela, 0, 3);
        };
        corpo.Controls.Add(Texto("Dados demonstrativos", 9, Argila), 0, 4);
        form.ResumeLayout(true);
    }
}
